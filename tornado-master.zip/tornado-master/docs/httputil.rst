``tornado.httputil`` --- Manipulate HTTP headers and URLs
=========================================================

.. testsetup::

   from tornado.httputil import *

.. automodule:: tornado.httputil
   :members:
